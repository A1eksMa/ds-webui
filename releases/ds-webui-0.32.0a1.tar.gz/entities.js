'use strict';

// Сущности: формирование столбцов таблицы из выбранных полей (браузерный
// Level 2) — типизация, парсинг чисел/дат/bool, резолюция коллизий,
// формульные показатели (kind: 'formula', formula.js). Самая рискованная
// логика в приложении — граничные случаи (серийная дата Excel, неоднозначные
// разделители) легче всего сломать правкой «на глаз», см. tests/entities.test.js.
// Зависит от formula.js (должен грузиться раньше, см. index.html) -- formula.js
// сам не зависит от entities.js, иначе был бы цикл.
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = factory(require('./formula.js'));
  } else {
    root.DS_APP = root.DS_APP || {};
    Object.assign(root.DS_APP, factory(root.DS_APP));
  }
})(typeof window !== 'undefined' ? window : this, function (Formula) {

  // ручная ширина столбцов «Таблицы» (px); та же шкала уходит в выгрузку Excel
  var DEFAULT_COL_W = 150;   // px, если для столбца ничего не задано
  var MIN_COL_W = 48;        // px, ниже не ужимаем перетаскиванием

  // выбранная/дефолтная ширина столбца c в px: пользовательская → формат сущности → дефолт
  var colWidthPx = function (state) {
    var cw = (state.preset && state.preset.view && state.preset.view.column_widths) || {};
    var em = {};
    ((state.dataset && state.dataset.entities) || []).forEach(function (e) { em[e.name] = e; });
    return function (c) {
      return cw[c] || (em[c] && em[c].format && em[c].format.width) || DEFAULT_COL_W;
    };
  };

  var ENTITY_TYPES = [['text', 'текст'], ['number', 'число'], ['date', 'дата'], ['bool', 'логич.']];
  var ENTITY_KINDS = [['field', 'поле'], ['resolve', 'коллизия'], ['formula', 'формула']];
  var _ENT_TYPE = { text: 1, number: 1, date: 1, bool: 1 };
  var _ENT_KIND = { field: 1, resolve: 1, formula: 1 };
  var _DATE_TOKENS = /YYYY|MM|DD|HH|mm|ss/g;

  var _pad2 = function (n) { return (n < 10 ? '0' : '') + n; };

  // "1 234,56" / "1,234.56" / "99.00" -> число. Разделитель тысяч отбрасывается,
  // десятичный — последний из . или , (или явный opts.decimal).
  var parseNum = function (raw, opts) {
    if (raw == null) return { ok: false, value: null };
    var s = String(raw).replace(/[\s  ]/g, '').replace(/[^0-9.,eE+-]/g, '');
    if (!/\d/.test(s)) return { ok: false, value: null };
    var dec = (opts && opts.decimal) || 'auto';
    var lc = s.lastIndexOf(','), ld = s.lastIndexOf('.');
    var sep = dec === ',' ? ',' : dec === '.' ? '.' : (lc > ld ? ',' : (ld > -1 ? '.' : ''));
    var i = sep ? s.lastIndexOf(sep) : -1;
    if (i !== -1) {
      s = s.slice(0, i).replace(/[.,]/g, '') + '.' + s.slice(i + 1).replace(/[.,]/g, '');
    } else {
      s = s.replace(/[.,]/g, '');
    }
    var n = Number(s);
    return isFinite(n) ? { ok: true, value: n } : { ok: false, value: null };
  };

  var _mkDate = function (Y, M, D, h, m, s) {
    Y = +Y; M = +M; D = +D;
    var ms = Date.UTC(Y, M - 1, D, +(h || 0), +(m || 0), +(s || 0));
    var d = new Date(ms);
    if (isNaN(ms) || d.getUTCFullYear() !== Y || d.getUTCMonth() !== M - 1 || d.getUTCDate() !== D) {
      return { ok: false, ms: null };
    }
    return { ok: true, ms: ms };
  };

  // Серийная дата Excel/1900 (число дней от 1899-12-30, с исторической ошибкой
  // «1900 — високосный»). Константа 25569 = дней от этой эпохи до 1970-01-01.
  // Дробная часть — доля суток. Диапазон 1..2958465 = 1900-01-01 .. 9999-12-31.
  var _excelSerialToMs = function (n) {
    if (!isFinite(n) || n < 1 || n > 2958465) return null;
    return Math.round((n - 25569) * 86400000);
  };

  // fmt === 'auto' — пробуем распространённые формы (в т.ч. серийную дату Excel
  // 5–7 цифр); 'excel' / 'serial' — только серийная дата; иначе токенный шаблон
  // (YYYY MM DD HH mm ss с любыми разделителями). Всё в UTC — детерминировано.
  var parseDate = function (raw, fmt) {
    if (raw == null) return { ok: false, ms: null };
    var s = String(raw).trim();
    if (s === '') return { ok: false, ms: null };
    fmt = fmt || 'auto';
    if (fmt === 'excel' || fmt === 'serial') {
      var ems = _excelSerialToMs(Number(s.replace(',', '.')));
      return ems == null ? { ok: false, ms: null } : { ok: true, ms: ems };
    }
    if (fmt !== 'auto') {
      var toks = [];
      var reStr = fmt.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(_DATE_TOKENS, function (t) {
        toks.push(t); return t === 'YYYY' ? '(\\d{4})' : '(\\d{1,2})';
      });
      var mm = s.match(new RegExp('^' + reStr));
      if (!mm) return { ok: false, ms: null };
      var v = { YYYY: 1970, MM: 1, DD: 1, HH: 0, mm: 0, ss: 0 };
      toks.forEach(function (t, i) { v[t] = +mm[i + 1]; });
      return _mkDate(v.YYYY, v.MM, v.DD, v.HH, v.mm, v.ss);
    }
    if (/^\d{9,13}$/.test(s)) {
      var num = Number(s);
      return isFinite(num) ? { ok: true, ms: s.length <= 10 ? num * 1000 : num } : { ok: false, ms: null };
    }
    // серийная дата Excel: 5–7 цифр (≈ 1927…), опц. дробная часть суток.
    // Короче unix-таймстемпа (9+ цифр) — не пересекается.
    if (/^\d{5,7}(?:[.,]\d+)?$/.test(s)) {
      var esm = _excelSerialToMs(Number(s.replace(',', '.')));
      if (esm != null) return { ok: true, ms: esm };
    }
    var m;
    m = s.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
    if (m) return _mkDate(m[1], m[2], m[3], m[4], m[5], m[6]);
    m = s.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
    if (m) return _mkDate(m[3], m[2], m[1], m[4], m[5], m[6]);
    m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
    if (m) {
      var a = +m[1], b = +m[2];
      return _mkDate(m[3], a > 12 ? b : a, a > 12 ? a : b, m[4], m[5], m[6]);
    }
    var p = Date.parse(s);
    return isFinite(p) ? { ok: true, ms: p } : { ok: false, ms: null };
  };

  var formatDate = function (ms, out) {
    if (ms == null) return '';
    var d = new Date(ms);
    var map = {
      YYYY: d.getUTCFullYear(), MM: _pad2(d.getUTCMonth() + 1), DD: _pad2(d.getUTCDate()),
      HH: _pad2(d.getUTCHours()), mm: _pad2(d.getUTCMinutes()), ss: _pad2(d.getUTCSeconds())
    };
    return String(out || 'YYYY-MM-DD').replace(_DATE_TOKENS, function (t) { return map[t]; });
  };

  var parseBool = function (raw, trueTokens) {
    if (raw == null) return { ok: false, value: null };
    var s = String(raw).trim().toLowerCase();
    if (s === '') return { ok: false, value: null };
    var T = String(trueTokens || 'да,true,1,yes,y,+,истина').toLowerCase().split(/[,\s]+/).filter(Boolean);
    var F = ['нет', 'false', '0', 'no', 'n', '-', 'ложь'];
    if (T.indexOf(s) !== -1) return { ok: true, value: true };
    if (F.indexOf(s) !== -1) return { ok: true, value: false };
    return { ok: false, value: null };
  };

  var _numStr = function (n) {
    if (!isFinite(n)) return String(n);
    return (Math.abs(n) >= 1e15 || (n !== 0 && Math.abs(n) < 1e-6))
      ? String(n) : String(Number(n.toPrecision(15)));
  };

  // строка-значение -> {display, key, ok}; промах парсинга -> ok:false, key:null, сырой текст
  var typeCell = function (raw, entity) {
    var t = (entity && entity.type) || 'text';
    if (raw == null) return { display: null, key: null, ok: true };
    var p = (entity && entity.parse) || {};
    if (t === 'number') {
      var rn = parseNum(raw, p);
      return rn.ok ? { display: _numStr(rn.value), key: rn.value, ok: true }
                   : { display: String(raw), key: null, ok: false };
    }
    if (t === 'date') {
      var rd = parseDate(raw, p.date_in);
      return rd.ok ? { display: formatDate(rd.ms, p.date_out || 'YYYY-MM-DD'), key: rd.ms, ok: true }
                   : { display: String(raw), key: null, ok: false };
    }
    if (t === 'bool') {
      var rb = parseBool(raw, p['true']);
      return rb.ok ? { display: rb.value ? 'да' : 'нет', key: rb.value ? 1 : 0, ok: true }
                   : { display: String(raw), key: null, ok: false };
    }
    return { display: String(raw), key: String(raw).toLowerCase(), ok: true };
  };

  var _present = function (v, nullWins) {
    if (v === undefined || v === '') return false;
    if (v === null) return !!nullWins;
    return true;
  };

  // Агрегаторы для итоговых строк группировки (view-table.js), по типу индикатора --
  // какие функции предлагать в UI. Переиспользует Formula.FUNCTIONS целиком, ничего
  // нового не считая: SUM/AVG/MIN/MAX уже пропускают нечисловые/отсутствующие значения,
  // а __k для bool уже хранит true/false как 1/0 (typeCell выше) -- обычный SUM поверх
  // __k и есть "сумма, где true считается за 1", отдельная функция не нужна. Добавить
  // агрегатор для нового типа (например, text) -- просто дописать элемент сюда (и,
  // если понадобится функция, которой нет в formula.js::FUNCTIONS, добавить её туда);
  // aggregateGroup ниже ничего не знает про конкретные типы/функции напрямую.
  var AGG_FUNCS_BY_TYPE = {
    number: ['SUM', 'AVG', 'MIN', 'MAX', 'COUNT_NONEMPTY'],
    date: ['MIN', 'MAX', 'COUNT_NONEMPTY'],
    bool: ['SUM', 'COUNT_NONEMPTY'],
    text: []
  };
  var AGG_FUNC_LABELS = { SUM: 'сумма', AVG: 'среднее', MIN: 'минимум', MAX: 'максимум', COUNT_NONEMPTY: 'количество' };

  // rows -- строки группы ПОСЛЕ parseTypes (row.__k[column] -- числовой/epoch-ms/0-1
  // ключ), column -- имя столбца-индикатора, entity -- его сущность (тип + формат для
  // дат), fn -- имя функции из AGG_FUNCS_BY_TYPE[entity.type]. undefined, если функция
  // не подходит типу или результата нет (все значения пусты/нечисловые) -- показывается
  // как пустая ячейка, не как 0/ошибка.
  var aggregateGroup = function (rows, column, entity, fn) {
    var type = (entity && entity.type) || 'text';
    if (!AGG_FUNCS_BY_TYPE[type] || AGG_FUNCS_BY_TYPE[type].indexOf(fn) === -1) return undefined;
    var fnImpl = Formula.FUNCTIONS[fn];
    if (!fnImpl) return undefined;
    var args = rows.map(function (r) { return r.__k ? r.__k[column] : undefined; });
    var result = fnImpl(args);
    if (result === undefined) return undefined;
    if (fn === 'COUNT_NONEMPTY') return String(result);
    if (type === 'date') {
      var outFmt = (entity.parse && entity.parse.date_out) || 'YYYY-MM-DD';
      return formatDate(Number(result), outFmt);
    }
    return _numStr(Number(result));
  };

  // Буквы входов по порядку (A, B, ..., Z, AA, ...) -- та же нумерация, что в UI
  // (view-entities.js), formula.js::letterFor.
  var lettersForInputs = function (inputs) {
    return (inputs || []).map(function (_, i) { return Formula.letterFor(i); });
  };

  // одна ячейка сущности из строки join'а -> строка | null | undefined. parsed -- для
  // kind === 'formula', результат Formula.parse(...) по этой сущности (см. resolveEntities:
  // формула разбирается ОДИН РАЗ на сущность, не на каждую строку).
  var resolveCell = function (from, jrow, parsed) {
    from = from || {};
    if (from.kind === 'resolve') {
      var ins = (from.inputs || [])
        .map(function (x, i) { return { c: x.column, w: Number(x.weight) || 0, i: i }; })
        .filter(function (x) { return x.c; });
      ins.sort(function (a, b) { return b.w - a.w || a.i - b.i; });   // вес desc, затем порядок
      for (var k = 0; k < ins.length; k++) {
        if (_present(jrow[ins[k].c], from.null_wins)) return jrow[ins[k].c];
      }
      return undefined;
    }
    if (from.kind === 'formula') {
      if (!parsed || !parsed.ok) return undefined;   // ошибка разбора -- уже показана в UI
      var letters = {};
      var names = lettersForInputs(from.inputs);
      (from.inputs || []).forEach(function (inp, i) { letters[names[i]] = jrow[inp.column]; });
      return Formula.evaluate(parsed.ast, {
        letters: letters,
        lookupRaw: function (path) { return jrow[path]; }
      });
    }
    return jrow[from.column];   // kind === 'field'
  };

  var implicitEntities = function (columns, columnTypes) {
    var types = columnTypes || {};
    return columns.map(function (c) {
      return { name: c, type: types[c] || 'text', from: { kind: 'field', column: c } };
    });
  };

  var _uniqName = function (want, taken, idx) {
    var base = (want == null || String(want).trim() === '') ? 'столбец ' + (idx + 1) : String(want);
    var n = base, k = 2;
    while (taken[n] !== undefined) { n = base + ' (' + k + ')'; k++; }
    taken[n] = true;
    return n;
  };

  // итоговые (дедуплицированные) имена столбцов для набора сущностей —
  // ровно то, чем будут ключи строк после resolveEntities/parseTypes
  var entityOutNames = function (entities) {
    var taken = {};
    return (entities || []).map(function (e, i) { return _uniqName(e.name, taken, i); });
  };

  // joined {columns, rows} + [entity] -> {columns: имена сущностей, rows}
  var resolveEntities = function (joined, entities) {
    var names = entityOutNames(entities);
    // Формула разбирается ОДИН раз на сущность, не на каждую строку -- парсинг короткой
    // строки дёшев сам по себе, но делать его N_строк раз на каждую formula-сущность
    // бессмысленно, когда AST не меняется между строками одного build'а.
    var parsedByEntity = entities.map(function (e) {
      return e.from.kind === 'formula'
        ? Formula.parse(e.from.formula, lettersForInputs(e.from.inputs))
        : null;
    });
    var rows = joined.rows.map(function (jr) {
      var out = {};
      entities.forEach(function (e, i) { out[names[i]] = resolveCell(e.from, jr, parsedByEntity[i]); });
      return out;
    });
    return { columns: names, rows: rows };
  };

  // типизация: row[name] -> display; row.__k[name] -> ключ сортировки; row.__u[name] -> промах
  var parseTypes = function (ds, entities, names) {
    var rows = ds.rows.map(function (r) {
      var out = { __k: {}, __u: {} };
      entities.forEach(function (e, i) {
        var nm = names[i];
        var tc = typeCell(r[nm], e);
        out[nm] = tc.display;
        out.__k[nm] = tc.key;
        if (!tc.ok) out.__u[nm] = true;
      });
      return out;
    });
    return { columns: ds.columns, rows: rows };
  };

  // Единственная реализация "список выбранных полей пресета" (квалификация
  // имён -- "Источник.показатель" при >1 источника, иначе голое имя). Раньше
  // было три слегка расходящиеся копии (здесь, view-build.js, view-entities.js);
  // расхождение было не только в дублировании, но и в поведении: без
  // manifestSources источник с ещё не сузившимся выбором (labels: null --
  // старый/загруженный пресет, "выбраны все поля") давал пустой список вместо
  // полного. manifestSources — опционален (store.js дёргает эту функцию и до
  // того, как манифест прочитан, напр. в preset/addEntity при пустом state.manifest).
  var presetColumns = function (preset, manifestSources) {
    var names = Object.keys(preset.query.sources);
    var multi = names.length > 1;
    var sources = manifestSources || [];
    var out = [];
    names.forEach(function (n) {
      var explicit = preset.query.sources[n].labels;
      var labels = explicit;
      if (!labels) {
        var ms = sources.find(function (s) { return s.name === n; });
        labels = ms ? [ms.key].concat(ms.labels) : [];
      }
      labels.forEach(function (l) { out.push(multi ? n + '.' + l : l); });
    });
    return out;
  };

  // {источник: [показатель,...]} + manifest.sources -> {колонка: type}. Та же схема
  // квалификации имён, что presetColumns/joinSources ("Источник.показатель" при >1
  // источника, иначе голое имя) — иначе типы не совпадут со столбцами. Ключевая
  // колонка и показатель, которого ещё нет в манифесте (не опубликован источником,
  // манифест не загружен) -> "text" по умолчанию (см.
  // ds-loader/docs/reference/config.md#manifest -> label_types).
  var columnTypesFor = function (sourceLabels, manifestSources) {
    var names = Object.keys(sourceLabels);
    var multi = names.length > 1;
    var sources = manifestSources || [];
    var out = {};
    names.forEach(function (n) {
      var ms = sources.find(function (s) { return s.name === n; });
      var types = (ms && ms.label_types) || {};
      (sourceLabels[n] || []).forEach(function (l) {
        out[multi ? n + '.' + l : l] = types[l] || 'text';
      });
    });
    return out;
  };

  // Тип одной колонки по пресету (без JOIN/живых данных) — для дефолтов в редьюсере
  // store.js при добавлении индикатора (аналог presetColumns для типов).
  var columnType = function (preset, manifestSources, column) {
    var sourceLabels = {};
    Object.keys(preset.query.sources).forEach(function (n) {
      sourceLabels[n] = preset.query.sources[n].labels || [];
    });
    return columnTypesFor(sourceLabels, manifestSources)[column] || 'text';
  };

  var entityColumns = function (preset, manifestSources) {
    var used = {};
    preset.view.entities.forEach(function (e) {
      if (e.from && e.from.kind === 'field' && e.from.column) used[e.from.column] = 1;
    });
    return { all: presetColumns(preset, manifestSources), used: used };
  };

  var mergeEntity = function (cur, patch) {
    var out = Object.assign({}, cur, patch);
    if (patch.from) out.from = Object.assign({}, cur.from || {}, patch.from);
    if (patch.parse) out.parse = Object.assign({}, cur.parse || {}, patch.parse);
    if (patch.format) out.format = Object.assign({}, cur.format || {}, patch.format);
    return out;
  };

  // view.entities [{name, type, parse, format, from}] -> чистая форма
  var normalizeEntities = function (view) {
    var raw = Array.isArray(view.entities) ? view.entities : [];
    return raw.map(function (e) {
      e = e && typeof e === 'object' ? e : {};
      var f = e.from && typeof e.from === 'object' ? e.from : {};
      var kind = _ENT_KIND[f.kind] ? f.kind : 'field';
      var inputs = (Array.isArray(f.inputs) ? f.inputs : []).map(function (x) {
        x = x && typeof x === 'object' ? x : {};
        return {
          column: typeof x.column === 'string' ? x.column : '',
          weight: x.weight == null || x.weight === '' ? 0.5 : Number(x.weight)
        };
      }).filter(function (x) { return x.column; });
      var from = { kind: kind };
      if (kind === 'field') {
        from.column = typeof f.column === 'string' ? f.column : '';
      } else if (kind === 'resolve') {
        from.inputs = inputs;
        from.null_wins = f.null_wins !== false;
      } else {
        from.inputs = inputs;
        from.formula = typeof f.formula === 'string' ? f.formula : '';
      }
      var out = {
        name: typeof e.name === 'string' ? e.name : '',
        type: _ENT_TYPE[e.type] ? e.type : 'text',
        hidden: !!e.hidden,
        from: from
      };
      var p = e.parse && typeof e.parse === 'object' ? e.parse : null;
      if (p) {
        out.parse = {};
        if (p.date_in != null) out.parse.date_in = String(p.date_in);
        if (p.date_out != null) out.parse.date_out = String(p.date_out);
        if (p['true'] != null) out.parse['true'] = String(p['true']);
        if (p.decimal != null) out.parse.decimal = String(p.decimal);
      }
      var fm = e.format && typeof e.format === 'object' ? e.format : null;
      if (fm) {
        out.format = {};
        if (fm.width != null && fm.width !== '') out.format.width = Number(fm.width);
        if (['left', 'center', 'right'].indexOf(fm.align) !== -1) out.format.align = fm.align;
        if (fm.font_size != null && fm.font_size !== '') out.format.font_size = Number(fm.font_size);
      }
      return out;
    }).filter(function (e) {
      return e.from.kind === 'field' ? e.from.column !== '' : e.from.inputs.length > 0;
    });
  };

  var api = {
    MIN_COL_W: MIN_COL_W, colWidthPx: colWidthPx,
    ENTITY_TYPES: ENTITY_TYPES, ENTITY_KINDS: ENTITY_KINDS,
    parseNum: parseNum, parseDate: parseDate, formatDate: formatDate, parseBool: parseBool,
    typeCell: typeCell, resolveCell: resolveCell, implicitEntities: implicitEntities,
    entityOutNames: entityOutNames, resolveEntities: resolveEntities, parseTypes: parseTypes,
    presetColumns: presetColumns, entityColumns: entityColumns, mergeEntity: mergeEntity,
    normalizeEntities: normalizeEntities, columnTypesFor: columnTypesFor, columnType: columnType,
    lettersForInputs: lettersForInputs,
    AGG_FUNCS_BY_TYPE: AGG_FUNCS_BY_TYPE, AGG_FUNC_LABELS: AGG_FUNC_LABELS, aggregateGroup: aggregateGroup
  };

  return api;
});
